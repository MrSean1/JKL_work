# *_*coding:utf-8 *_*
all_account = {'main_account': 9023414,
               }
#
# account_level = dict()
#
# pos = {
#     '9017159': 10,
#     '9017158': 5
# }

em_user = '295861809@qq.com'
pwd = 'qxkrwbmoxosdbhfi'
address = ['295861809@qq.com', ]
smtp_server = 'smtp.qq.com'

# get_depth  完成返回值
# a = {'msg': 'success', 'code': 1,
#      'data': {'LOW': 1.12808, 'HIGH': 1.13223, 'TIME': '2019-04-17T03:34:11.000+0000', 'BID': 1.13103, 'ASK': 1.13119,
#               'POINT': 1e-05, 'DIGITS': 5.0, 'SPREAD': 16.0, 'STOPLEVEL': 10.0, 'LOTSIZE': 100000.0, 'TICKVALUE': 1.0,
#               'TICKSIZE': 1e-05, 'SWAPLONG': -2.38, 'SWAPSHORT': 0.72, 'STARTING': 0.0, 'EXPIRATION': 0.0,
#               'TRADEALLOWED': 1.0, 'MINLOT': 0.01, 'LOTSTEP': 0.01, 'MAXLOT': 1000.0, 'SWAPTYPE': 0.0,
#               'PROFITCALCMODE': 0.0, 'MARGINCALCMODE': 0.0, 'MARGININIT': 0.0, 'MARGINMAINTENANCE': 0.0,
#               'MARGINHEDGED': 0.0, 'MARGINREQUIRED': 226.24, 'FREEZELEVEL': 5.0}}
# b = {'msg': 'success', 'code': 1,
#      'data': {'LOW': 70.665, 'HIGH': 72.005, 'TIME': '2019-04-16T11:59:59.000+0000', 'BID': 71.555, 'ASK': 71.655,
#               'POINT': 0.001, 'DIGITS': 3.0, 'SPREAD': 100.0, 'STOPLEVEL': 20.0, 'LOTSIZE': 1.0, 'TICKVALUE': 0.001,
#               'TICKSIZE': 1e-05, 'SWAPLONG': 0.0, 'SWAPSHORT': 0.0, 'STARTING': 0.0, 'EXPIRATION': 0.0,
#               'TRADEALLOWED': 0.0, 'MINLOT': 1.0, 'LOTSTEP': 0.01, 'MAXLOT': 1000.0, 'SWAPTYPE': 0.0,
#               'PROFITCALCMODE': 2.0, 'MARGINCALCMODE': 3.0, 'MARGININIT': 0.0, 'MARGINMAINTENANCE': 0.0,
#               'MARGINHEDGED': 0.0, 'MARGINREQUIRED': 358.28, 'FREEZELEVEL': 10.0}}
# symbol：SKYWORKS
# c = {'msg': 'success', 'code': 1,
#      'data': {'LOW': 89.715, 'HIGH': 91.785, 'TIME': '2019-04-18T11:59:59.000+0000', 'BID': 89.925, 'ASK': 90.025,
#               'POINT': 0.001, 'DIGITS': 3.0, 'SPREAD': 100.0, 'STOPLEVEL': 20.0, 'LOTSIZE': 1.0, 'TICKVALUE': 0.001,
#               'TICKSIZE': 1e-05, 'SWAPLONG': 0.0, 'SWAPSHORT': 0.0, 'STARTING': 0.0, 'EXPIRATION': 0.0,
#               'TRADEALLOWED': 0.0, 'MINLOT': 1.0, 'LOTSTEP': 1.0, 'MAXLOT': 500.0, 'SWAPTYPE': 0.0,
#               'PROFITCALCMODE': 2.0, 'MARGINCALCMODE': 3.0, 'MARGININIT': 0.0, 'MARGINMAINTENANCE': 0.0,
#               'MARGINHEDGED': 0.0, 'MARGINREQUIRED': 1350.38, 'FREEZELEVEL': 10.0}}


# a = [[[[58845536, {'symbol': 'USDCHF', 'volume': 1, 'order_type': 'buy'}],
#        [58845537, {'symbol': 'USDCHF', 'volume': 2, 'order_type': 'buy'}],
#        [58845540, {'symbol': 'USDCHF', 'volume': 3, 'order_type': 'buy'}],
#        [58845542, {'symbol': 'USDCHF', 'volume': 1, 'order_type': 'buy'}],
#        [58845543, {'symbol': 'USDCHF', 'volume': 5, 'order_type': 'buy'}],
#        [58845544, {'symbol': 'USDCHF', 'volume': 3, 'order_type': 'buy'}]]]]
# b = [[58845536, {'symbol': 'USDCHF', 'volume': 1, 'order_type': 'buy'}],
#      [58845537, {'symbol': 'USDCHF', 'volume': 2, 'order_type': 'buy'}],
#      [58845540, {'symbol': 'USDCHF', 'volume': 3, 'order_type': 'buy'}],
#      [58845542, {'symbol': 'USDCHF', 'volume': 1, 'order_type': 'buy'}],
#      [58845543, {'symbol': 'USDCHF', 'volume': 5, 'order_type': 'buy'}],
#      [58845544, {'symbol': 'USDCHF', 'volume': 3, 'order_type': 'buy'}]]
